﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
[DisallowMultipleComponent]
public class Wheel : MonoBehaviour {
	[SerializeField]
	private VehicleController vp;
	private Transform m_tr;

	public Transform tr {
		get { return m_tr; }
	}

	[System.NonSerialized]
	public Suspension suspension;
	Vector3 localVelocity;
	float currentRPM, rawRPM;

	[Tooltip("Generate a sphere collider to represent the wheel for side collisions")]
	public bool generateHardCollider = true;
	SphereCollider sphereCol;//Hard collider
	Transform sphereColTr;//Hard collider transform

	public Rigidbody parentRigidbody;
	public Transform visual;

	[Space]
	public WheelContact contact = new WheelContact();
	[System.NonSerialized]
	public Vector3 forceApplicationPoint;//Point at which friction forces are applied
	[System.NonSerialized]
	public bool getContact = true;//Should the wheel try to get contact info?
	[System.NonSerialized]
	public bool grounded;

	[Header("Dimensions")]
	public float radius;
	public float grossor;

	[Header("Rotation")]
	[Tooltip("Apply friction forces at ground point")]
	public bool applyForceAtGroundContact;

	[System.NonSerialized]
	public float upRotation;
	[System.NonSerialized]
	public float sideRotation;
	[System.NonSerialized]
	public float travelDist;
	Vector3 upDir;//Up direction
	float circumference;

	[Tooltip("Curve for setting final RPM of wheel based on driving torque/brake force, x-axis = torque/brake force, y-axis = lerp between raw RPM and target RPM")]
	public AnimationCurve rpmBiasCurve = AnimationCurve.Linear(0, 0, 1, 1);

	[Tooltip("As the RPM of the wheel approaches this value, the RPM bias curve is interpolated with the default linear curve")]
	public float rpmBiasCurveLimit = Mathf.Infinity;


	[Header("Friction")]

	[Range(0, 1)]
	public float frictionSmoothness = 0.5f;
	public float forwardFriction = 1;
	public float sidewaysFriction = 1;
	public float forwardCurveStretch = 1;
	public float sidewaysCurveStretch = 1;
	public ForceMode wheelForceMode;
	Vector3 frictionForce = Vector3.zero;

	[Tooltip("X-axis = slip, y-axis = friction")]
	public AnimationCurve forwardFrictionCurve = AnimationCurve.Linear(0, 0, 1, 1);

	[Tooltip("X-axis = slip, y-axis = friction")]
	public AnimationCurve sidewaysFrictionCurve = AnimationCurve.Linear(0, 0, 1, 1);
	[System.NonSerialized]
	public float forwardSlip;
	[System.NonSerialized]
	public float sidewaysSlip;
	public enum SlipDependenceMode { dependent, forward, sideways, independent };
	public SlipDependenceMode slipDependence = SlipDependenceMode.sideways;
	[Range(0, 2)]
	public float forwardSlipDependence = 2;
	[Range(0, 2)]
	public float sidewaysSlipDependence = 2;

	[Tooltip("Adjusts how much friction the wheel has based on the normal of the ground surface. X-axis = normal dot product, y-axis = friction multiplier")]
	public AnimationCurve normalFrictionCurve = AnimationCurve.Linear(0, 1, 1, 1);

	[Tooltip("How much the suspension compression affects the wheel friction")]
	[Range(0, 1)]
	public float compressionFrictionFactor = 0.5f;

	[Range(0, 1)]
	public float forwardFrictionAmount = 0;
	[Range(0, 1)]
	public float sideFrictionAmount = 1;

	[System.NonSerialized]
	public Vector3 contactVelocity;//Velocity of contact point
	float actualEbrake;
	float actualTargetRPM;
	float actualTorque;

	private void Start() {
		m_tr = transform;
		suspension = GetComponentInParent<Suspension>();

		if (Application.isPlaying) {
			//Generate hard collider
			if (generateHardCollider) {
				GameObject sphereColNew = new GameObject("visual Collider");
				sphereColNew.layer = gameObject.layer;
				sphereColTr = sphereColNew.transform;
				sphereCol = sphereColNew.AddComponent<SphereCollider>();
				sphereColTr.parent = tr;
				sphereColTr.localPosition = Vector3.zero;
				sphereColTr.localRotation = Quaternion.identity;
				sphereCol.radius = Mathf.Min(grossor * 0.5f, radius * 0.5f);
				// sphereCol.material = GlobalControl.frictionlessMatStatic;
			}
		}
	}

	private void LateUpdate() {
		RotateWheel();

		if (!Application.isPlaying) {
			PositionVisual();
		}


	}

	private void FixedUpdate() {
		upDir = tr.up;
		circumference = Mathf.PI * radius * 2;
		localVelocity = parentRigidbody.GetPointVelocity(forceApplicationPoint);

		//Get proper inputs
		actualEbrake = suspension.ebrakeEnabled ? suspension.ebrakeForce : 0;
		actualTargetRPM = /*targetDrive.rpm **/ (suspension.driveInverted ? -1 : 1);
		actualTorque = /*suspension.driveEnabled ? Mathf.Abs(vp.accelInput) :*/ 0;

		// airTime = grounded ? 0 : airTime + Time.fixedDeltaTime;

		if (getContact) {
			GetWheelContact();
		} else if (grounded) {
			contact.point += localVelocity * Time.fixedDeltaTime;
		}

		forceApplicationPoint = applyForceAtGroundContact ? contact.point : tr.position;

		PositionVisual();
		GetRawRPM();
		// ApplyDrive();
		
		//Get travel distance
		travelDist = suspension.compression < travelDist || grounded ? suspension.compression : Mathf.Lerp(travelDist, suspension.compression, suspension.extendSpeed * Time.fixedDeltaTime);

		GetSlip();
		ApplyFriction();
	}

	void GetSlip() {
		if (grounded) {
			sidewaysSlip = (contact.relativeVelocity.z * 0.1f) / sidewaysCurveStretch;
			forwardSlip = (0.01f * (rawRPM - currentRPM)) / forwardCurveStretch;
		} else {
			sidewaysSlip = 0;
			forwardSlip = 0;
		}
	}

	void ApplyFriction() {
		if (grounded) {
			float forwardSlipFactor = (int)slipDependence == 0 || (int)slipDependence == 1 ? forwardSlip - sidewaysSlip : forwardSlip;
			float sidewaysSlipFactor = (int)slipDependence == 0 || (int)slipDependence == 2 ? sidewaysSlip - forwardSlip : sidewaysSlip;
			float forwardSlipDependenceFactor = Mathf.Clamp01(forwardSlipDependence - Mathf.Clamp01(Mathf.Abs(sidewaysSlip)));
			float sidewaysSlipDependenceFactor = Mathf.Clamp01(sidewaysSlipDependence - Mathf.Clamp01(Mathf.Abs(forwardSlip)));

			Vector3 forceDirection = new Vector3(
				forwardFrictionCurve.Evaluate(Mathf.Abs(forwardSlipFactor)) * -System.Math.Sign(forwardSlip) * forwardFriction * forwardSlipDependenceFactor * -suspension.flippedSideFactor * forwardFrictionAmount,
				0,
				sidewaysFrictionCurve.Evaluate(Mathf.Abs(sidewaysSlipFactor)) * -System.Math.Sign(sidewaysSlip) * sidewaysFriction * sidewaysSlipDependenceFactor * normalFrictionCurve.Evaluate(Mathf.Clamp01(Vector3.Dot(contact.normal, Vector3.up))) * sideFrictionAmount
			);

			frictionForce = Vector3.Lerp(frictionForce,
					tr.TransformDirection(forceDirection)
					* ((1 - compressionFrictionFactor) + (1 - suspension.compression) * compressionFrictionFactor * Mathf.Clamp01(Mathf.Abs(suspension.tr.InverseTransformDirection(localVelocity).z) * 10)) * contact.friction
				, 1 - frictionSmoothness);

			Debug.DrawRay(transform.position, tr.TransformDirection(forceDirection), Color.cyan);

			parentRigidbody.AddForceAtPosition(frictionForce, forceApplicationPoint, wheelForceMode);

			//If resting on a rigidbody, apply opposing force to it
			if (contact.collider.attachedRigidbody) {
				contact.collider.attachedRigidbody.AddForceAtPosition(-frictionForce, contact.point, wheelForceMode);
			}
		}
	}

	private void RotateWheel() {
		if (tr && suspension) {
			float ackermannVal = Mathf.Sign(suspension.steerAngle) == suspension.flippedSideFactor ? 1 + suspension.ackermannFactor : 1 - suspension.ackermannFactor;
			tr.localEulerAngles = new Vector3(suspension.camberAngle + suspension.casterAngle * suspension.steerAngle * suspension.flippedSideFactor, -suspension.toeAngle * suspension.flippedSideFactor + suspension.steerDegrees * ackermannVal, 0);
		}

		if (Application.isPlaying) {
			visual.Rotate(Vector3.forward, currentRPM * suspension.flippedSideFactor * Time.deltaTime);

			visual.localEulerAngles = new Vector3(0, 0, visual.localEulerAngles.z);
		}
	}

	private void PositionVisual() {
		if (suspension) {
			visual.position = suspension.maxCompressPoint + suspension.springDirection * suspension.suspensionDistance * (Application.isPlaying ? travelDist : suspension.targetCompression) +
				suspension.upDir * Mathf.Pow(Mathf.Max(Mathf.Abs(Mathf.Sin(suspension.sideAngle * Mathf.Deg2Rad)), Mathf.Abs(Mathf.Sin(suspension.casterAngle * Mathf.Deg2Rad))), 2) * radius +
				suspension.pivotOffset * suspension.tr.TransformDirection(Mathf.Sin(tr.localEulerAngles.y * Mathf.Deg2Rad), 0, Mathf.Cos(tr.localEulerAngles.y * Mathf.Deg2Rad))
				- suspension.pivotOffset * (Application.isPlaying ? suspension.forwardDir : suspension.tr.forward);
		}

		if (Application.isPlaying && generateHardCollider) {
			sphereColTr.position = visual.position;
		}
	}

	void GetRawRPM() {
		/////////////////////////////////////////////////
		float ebrakeInput = 0; // This goes in the manager
		float brakeInput = 0;
		/////////////////////////////////////////////////

		if (grounded) {
			rawRPM = (contact.relativeVelocity.x / circumference) * (Mathf.PI * 100) * -suspension.flippedSideFactor;
		} else {
			rawRPM = Mathf.Lerp(rawRPM, actualTargetRPM, (actualTorque + suspension.brakeForce * brakeInput + actualEbrake * ebrakeInput) * Time.timeScale);
		}
	}

	private void CalculateRPM(float brakeForce) {
		/////////////////////////////////////////////////
		float ebrakeInput = 0; // This goes in the manager
		/////////////////////////////////////////////////

		bool validTorque = (!(Mathf.Approximately(actualTorque, 0) && Mathf.Abs(actualTargetRPM) < 0.01f) && !Mathf.Approximately(actualTargetRPM, 0)) || brakeForce + actualEbrake * ebrakeInput > 0;

		currentRPM = Mathf.Lerp(rawRPM,
			Mathf.Lerp(
			Mathf.Lerp(rawRPM, actualTargetRPM, validTorque ? EvaluateTorque(actualTorque) : actualTorque)
			, 0, Mathf.Max(brakeForce, actualEbrake * ebrakeInput))
		, validTorque ? EvaluateTorque(actualTorque + brakeForce + actualEbrake * ebrakeInput) : actualTorque + brakeForce + actualEbrake * ebrakeInput);

		// targetDrive.feedbackRPM = Mathf.Lerp(currentRPM, rawRPM, feedbackRpmBias);
	}

	float EvaluateTorque(float t) {
		float torque = Mathf.Lerp(rpmBiasCurve.Evaluate(t), t, rawRPM / (rpmBiasCurveLimit * Mathf.Sign(actualTargetRPM)));
		return torque;
	}

	private void GetWheelContact() {
		float castDist = Mathf.Max(suspension.suspensionDistance * Mathf.Max(0.001f, suspension.targetCompression) + radius, 0.001f);
		RaycastHit[] wheelHits = Physics.RaycastAll(suspension.maxCompressPoint, suspension.springDirection, castDist, gameObject.layer);
		RaycastHit hit;
		int hitIndex = 0;
		bool validHit = false;
		float hitDist = Mathf.Infinity;

		//Loop through raycast hits to find closest one
		for (int i = 0; i < wheelHits.Length; i++) {
			if (!wheelHits[i].transform.IsChildOf(parentRigidbody.transform) && wheelHits[i].distance < hitDist) {
				hitIndex = i;
				hitDist = wheelHits[i].distance;
				validHit = true;
			}
		}

		//Set contact point variables
		if (validHit) {
			hit = wheelHits[hitIndex];

			// if (!grounded && impactSnd && ((tireHitClips.Length > 0) || (rimHitClip))) {
			// 	impactSnd.PlayOneShot(tireHitClips[Mathf.RoundToInt(Random.Range(0, tireHitClips.Length - 1))], Mathf.Clamp01(airTime * airTime));
			// 	impactSnd.pitch = Mathf.Clamp(airTime * 0.2f + 0.8f, 0.8f, 1);
			// }

			grounded = true;
			contact.distance = hit.distance - radius;
			contact.point = hit.point + localVelocity * Time.fixedDeltaTime;
			contact.grounded = true;
			contact.normal = hit.normal;
			contact.relativeVelocity = tr.InverseTransformDirection(localVelocity);
			contact.collider = hit.collider;
			SurfaceMaterial surface = hit.collider.GetComponent<SurfaceMaterial>();
			contact.friction = surface ? surface.friction : 1;

			if (hit.collider.attachedRigidbody) {
				contactVelocity = hit.collider.attachedRigidbody.GetPointVelocity(contact.point);
				contact.relativeVelocity -= tr.InverseTransformDirection(contactVelocity);
			} else {
				contactVelocity = Vector3.zero;
			}

			// GroundSurfaceInstance curSurface = hit.collider.GetComponent<GroundSurfaceInstance>();
			// TerrainSurface curTerrain = hit.collider.GetComponent<TerrainSurface>();
			// 
			// if (curSurface) {
			// 	contact.surfaceFriction = curSurface.friction;
			// 	contact.surfaceType = curSurface.surfaceType;
			// } else if (curTerrain) {
			// 	contact.surfaceType = curTerrain.GetDominantSurfaceTypeAtPoint(contact.point);
			// 	contact.surfaceFriction = curTerrain.GetFriction(contact.surfaceType);
			// } else {
			// 	contact.surfaceFriction = hit.collider.material.dynamicFriction * 2;
			// 	contact.surfaceType = 0;
			// }

			// if (contact.collider.CompareTag("Pop Tire") && airLeakTime == -1) {
			// 	Deflate();
			// }
		} else {
			grounded = false;
			contact.distance = suspension.suspensionDistance;
			contact.point = Vector3.zero;
			contact.grounded = false;
			contact.normal = upDir;
			contact.relativeVelocity = Vector3.zero;
			contact.collider = null;
			contactVelocity = Vector3.zero;
			contact.friction = 0;
		}
	}

	void OnDrawGizmosSelected() {
		m_tr = transform;

		if (tr.childCount > 0) {
			visual = tr.GetChild(0);
		}

		Gizmos.color = Color.white;
		GizmosExtra.DrawWireCylinder(visual.position, visual.forward, radius, grossor * 2);
	}
}

[System.Serializable]
public class WheelContact {
	public bool grounded;               //Is the contact point grounded?
	public Collider collider;           //The collider of the contact point
	public Vector3 point;               //The position of the contact point
	public Vector3 normal;              //The normal of the contact point
	public Vector3 relativeVelocity;    //Relative velocity between the wheel and the contact point object
	public float distance;              //Distance from the suspension to the contact point minus the wheel radius
	public float friction;     //The surface type identified by the surface types array of GroundSurfaceMaster
}

public static class GizmosExtra {
	public static void DrawWireCylinder(Vector3 pos, Vector3 dir, float radius, float height) {
		float halfHeight = height * 0.5f;
		Quaternion quat = Quaternion.LookRotation(dir, new Vector3(-dir.y, dir.x, 0));

		Gizmos.DrawLine(pos + quat * new Vector3(radius, 0, halfHeight), pos + quat * new Vector3(radius, 0, -halfHeight));
		Gizmos.DrawLine(pos + quat * new Vector3(-radius, 0, halfHeight), pos + quat * new Vector3(-radius, 0, -halfHeight));
		Gizmos.DrawLine(pos + quat * new Vector3(0, radius, halfHeight), pos + quat * new Vector3(0, radius, -halfHeight));
		Gizmos.DrawLine(pos + quat * new Vector3(0, -radius, halfHeight), pos + quat * new Vector3(0, -radius, -halfHeight));

		Vector3 circle0Point0;
		Vector3 circle0Point1;
		Vector3 circle1Point0;
		Vector3 circle1Point1;

		for (float i = 0; i < 6.28f; i += 0.1f) {
			circle0Point0 = pos + quat * new Vector3(Mathf.Sin(i) * radius, Mathf.Cos(i) * radius, halfHeight);
			circle0Point1 = pos + quat * new Vector3(Mathf.Sin(i + 0.1f) * radius, Mathf.Cos(i + 0.1f) * radius, halfHeight);
			Gizmos.DrawLine(circle0Point0, circle0Point1);

			circle1Point0 = pos + quat * new Vector3(Mathf.Sin(i) * radius, Mathf.Cos(i) * radius, -halfHeight);
			circle1Point1 = pos + quat * new Vector3(Mathf.Sin(i + 0.1f) * radius, Mathf.Cos(i + 0.1f) * radius, -halfHeight);
			Gizmos.DrawLine(circle1Point0, circle1Point1);
		}
	}
}