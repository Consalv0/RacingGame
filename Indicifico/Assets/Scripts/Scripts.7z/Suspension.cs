﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[ExecuteInEditMode]
[DisallowMultipleComponent]
public class Suspension : MonoBehaviour {
	private Transform m_tr;
	private Rigidbody m_rb;

	public Transform tr {
		get { return m_tr; }
	}

	public Rigidbody rb {
		get { return m_rb; }
	}
	// VehicleParent vp;

	//Variables for inverting certain values on opposite sides of the vehicle
	[System.NonSerialized]
	public bool flippedSide;
	[System.NonSerialized]
	public float flippedSideFactor;
	[System.NonSerialized]
	public Quaternion initialRotation;

	public Wheel wheel;
	CapsuleCollider compressCol;//The hard collider

	// [Tooltip("Generate a capsule collider for hard compressions")]
	// public bool generateHardCollider = false;
	// 
	// [Tooltip("Multiplier for the radius of the hard collider")]
	// public float hardColliderRadiusFactor = 1;
	// float hardColliderRadiusFactorPrev;
	// float setHardColliderRadiusFactor;
	// Transform compressTr;//Transform component of the hard collider

	[Header("Brakes and Steering")]
	public float brakeForce = 0.5F;
	public float ebrakeForce = 0.0F;

	[Range(-180, 180)]
	public float steerRangeMin = -40;
	[Range(-180, 180)]
	public float steerRangeMax = 40;

	[Tooltip("How much the wheel is steered")]
	public float steerFactor = 1;
	[Range(-1, 1)]
	public float steerAngle = 0;
	[System.NonSerialized]
	public float steerDegrees;

	[Tooltip("Effect of Ackermann steering geometry")]
	public float ackermannFactor = 0.1F;

	[Tooltip("The camber of the wheel as it travels, x-axis = compression, y-axis = angle")]
	public AnimationCurve camberCurve = AnimationCurve.Linear(0, 0, 1, 0);
	[Range(-89.999f, 89.999f)]
	public float camberOffset;
	[System.NonSerialized]
	public float camberAngle;

	[Tooltip("Adjust the camber as if it was connected to a solid axle, opposite wheel must be set")]
	public bool solidAxleCamber;
	public Suspension oppositeWheel;

	[Tooltip("Angle at which the suspension points out to the side")]
	[Range(-89.999f, 89.999f)]
	public float sideAngle;
	[Range(-89.999f, 89.999f)]
	public float casterAngle;
	[Range(-89.999f, 89.999f)]
	public float toeAngle;

	[Tooltip("Wheel offset from its pivot point")]
	public float pivotOffset = 0.12F;
	// [System.NonSerialized]
	// public List<SuspensionPart> movingParts = new List<SuspensionPart>();

	[Header("Spring")]
	public float suspensionDistance = 0.13F;
	[System.NonSerialized]
	public float compression;
	public ForceMode forceMode;

	[Tooltip("Should be left at 1 unless testing suspension travel")]
	[Range(0, 1)]
	public float targetCompression = 1;
	[System.NonSerialized]
	public float penetration;//How deep the ground is interesecting with the wheel's tire
	public float springForce = 5;

	[Tooltip("Force of the curve depending on it's compression, x-axis = compression, y-axis = force")]
	public AnimationCurve springForceCurve = AnimationCurve.Linear(0, 0, 1, 1);

	[Tooltip("Exponent for spring force based on compression")]
	public float springExponent = 10;
	public float springDampening = 0.5F;

	[Tooltip("How quickly the suspension extends if it's not grounded")]
	public float extendSpeed = 20;

	[Tooltip("Apply forces to prevent the wheel from intersecting with the ground, not necessary if generating a hard collider")]
	public bool applyHardContactForce = true;
	public float hardContactForce = 10;
	public float hardContactSensitivity = 2;

	[Tooltip("Apply suspension forces at ground point")]
	public bool applyForceAtGroundContact = true;

	[Tooltip("Apply suspension forces along local up direction instead of ground normal")]
	public bool leaningForce;

	[System.NonSerialized]
	public Vector3 maxCompressPoint;//Position of the wheel when the suspension is compressed all the way
	[System.NonSerialized]
	public Vector3 springDirection;
	[System.NonSerialized]
	public Vector3 upDir;//Local up direction
	[System.NonSerialized]
	public Vector3 forwardDir;//Local forward direction

	// [System.NonSerialized]
	// public DriveForce targetDrive;//The drive being passed into the wheel

	// [System.NonSerialized]
	// public SuspensionPropertyToggle properties;//Property toggler
	[Header("Suspension Properties")]
	public bool steerEnabled = true;
	public bool steerInverted;
	public bool driveEnabled = true;
	public bool driveInverted;
	public bool ebrakeEnabled = true;
	public bool skidSteerBrake;

	void Start() {
		m_tr = transform;
		m_rb = GetComponentInParent<Rigidbody>();
		// vp = (VehicleParent)F.GetTopmostParentComponent<VehicleParent>(tr);
		// targetDrive = GetComponent<DriveForce>();
		flippedSide = Vector3.Dot(tr.forward, rb.transform.right) < 0;
		flippedSideFactor = flippedSide ? -1 : 1;
		initialRotation = tr.localRotation;

		if (Application.isPlaying) {
			GetCamber();

			// //Generate the hard collider
			// if (generateHardCollider) {
			// 	GameObject cap = new GameObject("Compress Collider");
			// 	cap.layer = gameObject.layer;
			// 	compressTr = cap.transform;
			// 	compressTr.parent = tr;
			// 	compressTr.localPosition = Vector3.zero;
			// 	compressTr.localEulerAngles = new Vector3(camberAngle, 0, -casterAngle * flippedSideFactor);
			// 	compressCol = cap.AddComponent<CapsuleCollider>();
			// 	compressCol.direction = 1;
			// 	setHardColliderRadiusFactor = hardColliderRadiusFactor;
			// 	hardColliderRadiusFactorPrev = setHardColliderRadiusFactor;
			// 	compressCol.radius = wheel.grossor * hardColliderRadiusFactor;
			// 	compressCol.height = wheel.radius * 2;
			// 	// compressCol.material = GlobalControl.frictionlessMatStatic;
			// }

			steerRangeMax = Mathf.Max(steerRangeMin, steerRangeMax);

			// properties = GetComponent<SuspensionPropertyToggle>();
			// if (properties) {
			// 	UpdateProperties();
			// }
		}
	}

	void FixedUpdate() {
		upDir = tr.up;
		forwardDir = tr.forward;
		targetCompression = 1;

		GetCamber();

		GetSpringVectors();
		
		compression = Mathf.Min(targetCompression, suspensionDistance > 0 ? Mathf.Clamp01(wheel.contact.distance / suspensionDistance) : 0);
		penetration = Mathf.Min(0, wheel.contact.distance);

		if (targetCompression > 0) {
			ApplySuspensionForce();
		}

		//Set hard collider size if it is changed during play mode
		// if (generateHardCollider) {
		// 	setHardColliderRadiusFactor = hardColliderRadiusFactor;
		// 
		// 	if (hardColliderRadiusFactorPrev != setHardColliderRadiusFactor) {
		// 		compressCol.direction = 2;
		// 		compressCol.radius = wheel.radius * hardColliderRadiusFactor;
		// 		compressCol.height = wheel.grossor * 2;
		// 	}
		// 
		// 	hardColliderRadiusFactorPrev = setHardColliderRadiusFactor;
		// }

		//Set the drive of the wheel
		// if (wheel.targetDrive) {
		// 	targetDrive.active = driveEnabled;
		// 	targetDrive.feedbackRPM = wheel.targetDrive.feedbackRPM;
		// 	wheel.targetDrive.SetDrive(targetDrive);
		// }
	}

	void Update() {
		GetCamber();

		if (!Application.isPlaying) {
			GetSpringVectors();
		}

		//Set steer angle for the wheel
		steerDegrees = Mathf.Abs(steerAngle) * (steerAngle > 0 ? steerRangeMax : steerRangeMin);
	}

	void ApplySuspensionForce() {
		if (wheel.contact.grounded) {
			//Get the local vertical velocity
			Debug.DrawRay(tr.position, rb.transform.InverseTransformDirection(Quaternion.AngleAxis(90, rb.transform.right) * rb.GetPointVelocity(tr.position)), Color.green);
			float travelVel = rb.transform.InverseTransformDirection(Quaternion.AngleAxis(90, rb.transform.right) * rb.GetPointVelocity(tr.position)).z;

			//Apply the suspension force
			if (suspensionDistance > 0 && targetCompression > 0) {
				Vector3 appliedSuspensionForce = (leaningForce ? Vector3.Lerp(upDir, rb.transform.forward, Mathf.Abs(Mathf.Pow(Vector3.Dot(rb.transform.forward, rb.transform.up), 5))) : rb.transform.up) * springForce * (Mathf.Pow(springForceCurve.Evaluate(1 - compression), Mathf.Max(1, springExponent)) - (1 - targetCompression) - springDampening * Mathf.Clamp(travelVel, -1, 1));

				Debug.DrawRay(tr.position, appliedSuspensionForce, Color.red);

				rb.AddForceAtPosition(
					appliedSuspensionForce
					, applyForceAtGroundContact ? wheel.contact.point : wheel.tr.position
					, forceMode);

				//If wheel is resting on a rigidbody, apply opposing force to it
				if (wheel.contact.collider.attachedRigidbody) {
					wheel.contact.collider.attachedRigidbody.AddForceAtPosition(
						-appliedSuspensionForce
						, wheel.contact.point
						, forceMode);
				}
			}

			//Apply hard contact force
			if (compression == 0 && applyHardContactForce) {
				rb.AddForceAtPosition(
					-rb.transform.TransformDirection(0, 0, Mathf.Clamp(travelVel, -hardContactSensitivity * Time.fixedDeltaTime, 0) + penetration) * hardContactForce * Mathf.Clamp01(Time.fixedDeltaTime)
					, applyForceAtGroundContact ? wheel.contact.point : wheel.tr.position
					, forceMode);
			}
		}
	}

	void GetSpringVectors() {
		if (!Application.isPlaying) {
			m_tr = transform;
			m_rb = GetComponentInParent<Rigidbody>();
			flippedSide = Vector3.Dot(tr.forward, rb.transform.right) < 0;
			flippedSideFactor = flippedSide ? -1 : 1;
		}

		maxCompressPoint = tr.position;

		float casterDir = -Mathf.Sin(casterAngle * Mathf.Deg2Rad) * flippedSideFactor;
		float sideDir = -Mathf.Sin(sideAngle * Mathf.Deg2Rad);

		springDirection = tr.TransformDirection(casterDir, Mathf.Max(Mathf.Abs(casterDir), Mathf.Abs(sideDir)) - 1, sideDir).normalized;
	}

	void GetCamber() {
		if (solidAxleCamber && oppositeWheel) {
			if (oppositeWheel.wheel.visual && wheel.visual) {
				Vector3 axleDir = tr.InverseTransformDirection((oppositeWheel.wheel.visual.position - wheel.visual.position).normalized);
				camberAngle = Mathf.Atan2(axleDir.z, axleDir.y) * Mathf.Rad2Deg + 90 + camberOffset;
			}
		} else {
			camberAngle = camberCurve.Evaluate((Application.isPlaying ? wheel.travelDist : targetCompression)) + camberOffset;
		}
	}

	//Visualize steer range
	void OnDrawGizmosSelected() {
		if (!tr) {
			m_tr = transform;
		}

		if (wheel) {
			if (wheel.visual) {
				Vector3 wheelPoint = wheel.visual.position;

				float camberSin = -Mathf.Sin(camberAngle * Mathf.Deg2Rad);
				float steerSin = Mathf.Sin(Mathf.Lerp(steerRangeMin, steerRangeMax, (steerAngle + 1) * 0.5f) * Mathf.Deg2Rad);
				float minSteerSin = Mathf.Sin(steerRangeMin * Mathf.Deg2Rad);
				float maxSteerSin = Mathf.Sin(steerRangeMax * Mathf.Deg2Rad);

				Gizmos.color = Color.magenta;

				Gizmos.DrawWireSphere(wheelPoint, 0.05f);

				Gizmos.DrawLine(wheelPoint, wheelPoint + tr.TransformDirection(minSteerSin
					, camberSin * (1 - Mathf.Abs(minSteerSin))
					, Mathf.Cos(steerRangeMin * Mathf.Deg2Rad) * (1 - Mathf.Abs(camberSin))
					).normalized);

				Gizmos.DrawLine(wheelPoint, wheelPoint + tr.TransformDirection(maxSteerSin
					, camberSin * (1 - Mathf.Abs(maxSteerSin))
					, Mathf.Cos(steerRangeMax * Mathf.Deg2Rad) * (1 - Mathf.Abs(camberSin))
					).normalized);

				Gizmos.DrawLine(wheelPoint + tr.TransformDirection(minSteerSin
					, camberSin * (1 - Mathf.Abs(minSteerSin))
					, Mathf.Cos(steerRangeMin * Mathf.Deg2Rad) * (1 - Mathf.Abs(camberSin))
					).normalized * 0.9f
				, wheelPoint + tr.TransformDirection(maxSteerSin
					, camberSin * (1 - Mathf.Abs(maxSteerSin))
					 , Mathf.Cos(steerRangeMax * Mathf.Deg2Rad) * (1 - Mathf.Abs(camberSin))
					).normalized * 0.9f);

				Gizmos.DrawLine(wheelPoint, wheelPoint + tr.TransformDirection(steerSin
					, camberSin * (1 - Mathf.Abs(steerSin))
					, Mathf.Cos(steerRangeMin * Mathf.Deg2Rad) * (1 - Mathf.Abs(camberSin))
					).normalized);
			}
		}

		Gizmos.color = Color.red;
	}
}