﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Rigidbody))]
[DisallowMultipleComponent]

//Vehicle root class
public class VehicleController : MonoBehaviour {
	[System.NonSerialized]
	public Rigidbody rb;
	[System.NonSerialized]
	public Transform tr;

	[System.NonSerialized]
	public float accelInput;
	[System.NonSerialized]
	public float brakeInput;
	[System.NonSerialized]
	public float steerInput;
	[System.NonSerialized]
	public float ebrakeInput;
	[System.NonSerialized]
	public bool boostButton;
	[System.NonSerialized]
	public bool upshiftPressed;
	[System.NonSerialized]
	public bool downshiftPressed;
	[System.NonSerialized]
	public float upshiftHold;
	[System.NonSerialized]
	public float downshiftHold;
	[System.NonSerialized]
	public float pitchInput;
	[System.NonSerialized]
	public float yawInput;
	[System.NonSerialized]
	public float rollInput;

	[Tooltip("Accel axis is used for brake input")]
	public bool accelAxisIsBrake;

	[Tooltip("Brake input will act as reverse input")]
	public bool brakeIsReverse;

	[Tooltip("Automatically hold ebrake if it's pressed while parked")]
	public bool holdEbrakePark;

	bool stopUpshift;
	bool stopDownShift;

	[System.NonSerialized]
	public Vector3 localVelocity;//Local space velocity
	[System.NonSerialized]
	public Vector3 localAngularVel;//Local space angular velocity
	[System.NonSerialized]
	public Vector3 forwardDir;//Forward direction
	[System.NonSerialized]
	public Vector3 rightDir;//Right direction
	[System.NonSerialized]
	public Vector3 upDir;//Up direction
	[System.NonSerialized]
	public float forwardDot;//Dot product between forwardDir and GlobalControl.worldUpDir
	[System.NonSerialized]
	public float rightDot;//Dot product between rightDir and GlobalControl.worldUpDir
	[System.NonSerialized]
	public float upDot;//Dot product between upDir and GlobalControl.worldUpDir
	[System.NonSerialized]
	public float velMag;//Velocity magnitude
	[System.NonSerialized]
	public float sqrVelMag;//Velocity squared magnitude

	[System.NonSerialized]
	public bool reversing;

	public Wheel[] wheels;
	[System.NonSerialized]
	public int groundedWheels;//Number of wheels grounded
	[System.NonSerialized]
	public Vector3 wheelNormalAverage;//Average normal of the wheel contact points
	Vector3 wheelContactsVelocity;//Average velocity of wheel contact points

	[Tooltip("Lower center of mass by suspension height")]
	public bool suspensionCenterOfMass;
	public Vector3 centerOfMassOffset;

	void Start() {
		tr = transform;
		rb = GetComponent<Rigidbody>();
		
		SetCenterOfMass();
	}

	void Update() {
		//Shift single frame pressing logic
		if (stopUpshift) {
			upshiftPressed = false;
			stopUpshift = false;
		}

		if (stopDownShift) {
			downshiftPressed = false;
			stopDownShift = false;
		}

		if (upshiftPressed) {
			stopUpshift = true;
		}

		if (downshiftPressed) {
			stopDownShift = true;
		}
	}

	void FixedUpdate() {
		GetGroundedWheels();

		localVelocity = tr.InverseTransformDirection(rb.velocity - wheelContactsVelocity);
		localAngularVel = tr.InverseTransformDirection(rb.angularVelocity);
		velMag = rb.velocity.magnitude;
		sqrVelMag = rb.velocity.sqrMagnitude;
		forwardDir = tr.forward;
		rightDir = tr.right;
		upDir = tr.up;
		forwardDot = Vector3.Dot(forwardDir, Vector3.up);
		rightDot = Vector3.Dot(rightDir, Vector3.up);
		upDot = Vector3.Dot(upDir, Vector3.up);

		//Check if reversing
		if (brakeIsReverse && brakeInput > 0 && localVelocity.z < 1) {
			reversing = true;
		} else if (localVelocity.z >= 0) {
			reversing = false;
		}
	}

	public void SetAccel(float f) {
		f = Mathf.Clamp(f, -1, 1);
		accelInput = f;
	}

	public void SetBrake(float f) {
		brakeInput = accelAxisIsBrake ? -Mathf.Clamp(accelInput, -1, 0) : Mathf.Clamp(f, -1, 1);
	}

	public void SetSteer(float f) {
		steerInput = Mathf.Clamp(f, -1, 1);
	}

	public void SetEbrake(float f) {
		if ((f > 0 || ebrakeInput > 0) && holdEbrakePark && velMag < 1 && accelInput == 0 && (brakeInput == 0 || !brakeIsReverse)) {
			ebrakeInput = 1;
		} else {
			ebrakeInput = Mathf.Clamp01(f);
		}
	}

	public void SetBoost(bool b) {
		boostButton = b;
	}

	public void SetPitch(float f) {
		pitchInput = Mathf.Clamp(f, -1, 1);
	}

	public void SetYaw(float f) {
		yawInput = Mathf.Clamp(f, -1, 1);
	}

	public void SetRoll(float f) {
		rollInput = Mathf.Clamp(f, -1, 1);
	}

	public void PressUpshift() {
		upshiftPressed = true;
	}

	public void PressDownshift() {
		downshiftPressed = true;
	}

	public void SetUpshift(float f) {
		upshiftHold = f;
	}

	public void SetDownshift(float f) {
		downshiftHold = f;
	}
	
	void SetCenterOfMass() {
		float suspensionAverage = 0;

		//Get average suspension height
		if (suspensionCenterOfMass) {
			for (int i = 0; i < wheels.Length; i++) {
				float newSusDist = wheels[i].transform.parent.GetComponent<Suspension>().suspensionDistance;
				suspensionAverage = i == 0 ? newSusDist : (suspensionAverage + newSusDist) * 0.5f;
			}

			rb.centerOfMass = centerOfMassOffset + new Vector3(0, -suspensionAverage, 0);
			rb.inertiaTensor = rb.inertiaTensor;//This is required due to decoupling of inertia tensor from center of mass in Unity 5.3
		}
	}

	void GetGroundedWheels() {
		groundedWheels = 0;
		wheelContactsVelocity = Vector3.zero;
		for (int i = 0; i < wheels.Length; i++) {
			if (wheels[i].grounded) {
				wheelContactsVelocity = i == 0 ? wheels[i].contactVelocity : (wheelContactsVelocity + wheels[i].contactVelocity) * 0.5f;
				wheelNormalAverage = i == 0 ? wheels[i].contact.normal : (wheelNormalAverage + wheels[i].contact.normal).normalized;
			}

			if (wheels[i].grounded) {
				groundedWheels++;
			}
		}

	}
}